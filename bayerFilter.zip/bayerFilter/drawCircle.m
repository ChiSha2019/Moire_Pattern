function display = drawOctagon()
    display = zeros(10,10,3);
    display(1,4:5,1) = 255;
    display(2,3:5,1) = 255;
    display(3,2:5,1) = 255;
    display(4,1:5,1) = 255;
    display(5,1:5,1) = 255;

    display(6:10,:,1) = display(5:-1:1,:,1);
    display(:,6:10,:) = display(:,5:-1:1,:);

    %white line
    display(4:6,4:7,1:3) = 1;
end

